"use strict";
const http=require("node:http");
const fs=require("node:fs");
const path=require("node:path");
const root=path.resolve(__dirname,"..");
const files=new Map([
  ["index.html","text/html; charset=utf-8"],["chapters.js","text/javascript; charset=utf-8"],
  ["poster.jpg","image/jpeg"],["推栏前端工作流_成果宣传片.mp4","video/mp4"],
]);
const [host,port]=process.argv.slice(2);
http.createServer((req,res)=>{
  if (!["GET","HEAD"].includes(req.method)) {res.writeHead(405).end();return;}
  let name;
  try {name=decodeURIComponent(new URL(req.url,"http://localhost").pathname.slice(1))||"index.html";}
  catch {res.writeHead(400).end();return;}
  if(!files.has(name)){res.writeHead(404).end();return;}
  const file=path.join(root,name);
  let size;
  try{size=fs.statSync(file).size;}catch{res.writeHead(404).end();return;}
  const headers={"Content-Type":files.get(name),"Content-Length":size,"Accept-Ranges":"bytes",
    "Cache-Control":"no-cache","X-Content-Type-Options":"nosniff"};
  let start=0,end=size-1;
  if(req.headers.range){
    const match=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
    if(match&&(match[1]||match[2])){
      start=match[1]?Number(match[1]):Math.max(0,size-Number(match[2]));
      end=match[1]&&match[2]?Math.min(size-1,Number(match[2])):size-1;
    }else{start=size;}
    if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=size){res.writeHead(416,{"Content-Range":"bytes */"+size}).end();return;}
    headers["Content-Range"]=`bytes ${start}-${end}/${size}`;
    headers["Content-Length"]=end-start+1;
  }
  res.writeHead(req.headers.range?206:200,headers);
  if(req.method==="HEAD"){res.end();return;}
  const stream=fs.createReadStream(file,{start,end});
  res.on("close",()=>stream.destroy());
  stream.on("error",()=>res.destroy());
  stream.pipe(res);
}).listen(Number(port),host,()=>console.log(`http://${host}:${port}/`));

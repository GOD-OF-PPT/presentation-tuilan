"use strict";

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const address = process.argv[2];
const port = Number(process.argv[3]);
if (!address || !Number.isInteger(port) || port < 1024 || port > 65535) {
  throw new Error("Usage: node 制作/share.cjs <LAN IPv4 address> <port>");
}

const dataFile = fs.readFileSync(path.join(root, "data.js"), "utf8").trim();
const data = JSON.parse(dataFile.replace(/^window\.REPORT = /, "").replace(/;$/, ""));
const files = new Set(["index.html", "player.js", "report.css", "data.js", "design/a.png", "media/narration.mp3"]);
for (const scene of data.scenes) {
  const media = [...scene.images, ...(scene.clips || [])];
  if (scene.demo) media.push(scene.demo);
  for (const asset of media) {
    if (!/^media\/[\w.\-]+$/.test(asset)) throw new Error(`Unexpected media path: ${asset}`);
    files.add(asset);
  }
}

const allowed = new Map();
for (const relative of files) {
  const filename = path.join(root, relative);
  if (!fs.lstatSync(filename).isFile()) throw new Error(`Missing report asset: ${relative}`);
  allowed.set(relative, filename);
}

const contentTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".mp3": "audio/mpeg",
  ".mp4": "video/mp4",
};

function readRange(header, length) {
  const match = /^bytes=(\d*)-(\d*)$/.exec(header);
  if (!match || (!match[1] && !match[2])) return null;
  const start = match[1] ? Number(match[1]) : Math.max(0, length - Number(match[2]));
  const end = match[1] && match[2] ? Math.min(length - 1, Number(match[2])) : length - 1;
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start >= length || start > end) return null;
  return { start, end };
}

http.createServer((request, response) => {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("Cache-Control", "no-cache");
  if (!["GET", "HEAD"].includes(request.method)) {
    response.writeHead(405, { Allow: "GET, HEAD" }).end();
    return;
  }
  let relative;
  try {
    const pathname = decodeURIComponent(new URL(request.url, "http://localhost").pathname);
    relative = pathname === "/" ? "index.html" : pathname.slice(1);
  } catch {
    response.writeHead(400).end();
    return;
  }
  const generatedNarration = /^media\/narration-[0-9a-f]{16}\.mp3$/.test(relative);
  const filename = allowed.get(relative) || (generatedNarration ? path.join(root, relative) : undefined);
  if (!filename) {
    response.writeHead(404).end();
    return;
  }
  let length;
  try {
    const asset = fs.lstatSync(filename);
    if (!asset.isFile()) {
      response.writeHead(404).end();
      return;
    }
    length = asset.size;
  } catch {
    response.writeHead(404).end();
    return;
  }
  const headers = {
    "Content-Type": contentTypes[path.extname(filename)] || "application/octet-stream",
    "Accept-Ranges": "bytes",
    "Content-Length": length,
  };
  let range;
  if (request.headers.range) {
    range = readRange(request.headers.range, length);
    if (!range) {
      response.writeHead(416, { "Content-Range": `bytes */${length}` }).end();
      return;
    }
    headers["Content-Range"] = `bytes ${range.start}-${range.end}/${length}`;
    headers["Content-Length"] = range.end - range.start + 1;
  }
  response.writeHead(range ? 206 : 200, headers);
  if (request.method === "HEAD") {
    response.end();
    return;
  }
  const stream = fs.createReadStream(filename, range);
  response.on("close", () => stream.destroy());
  stream.on("error", () => response.destroy());
  stream.pipe(response);
}).listen(port, address, () => console.log(`http://${address}:${port}/ (${allowed.size} report files)`));

"use strict";

const { scenes, captions, seconds, narrationFile, narrationVersion } = window.REPORT;
const $ = (id) => document.getElementById(id);
const presentation = $("presentation");
if (location.protocol === "http:" || location.protocol === "https:") {
  const promoUrl = new URL("/", location.href);
  promoUrl.port = "8790";
  $("promo-link").href = promoUrl.href;
}
const stage = $("scene");
const audio = $("narration");
const progress = $("seek");
const playButton = $("play");
const caption = $("caption");
const status = $("status");
const zoom = $("zoom");
const chapters = ["背景", "新页面设计", "迁移工作流", "公共业务能力库", "公共业务能力库测试", "提效总览", "下一阶段"];
const names = {
  4: "功能图谱",
  5: "职责与交接",
  6: "江湖榜单 · 发起任务",
  7: "江湖榜单 · 确认范围",
  8: "江湖榜单 · 分组与验收准备",
  9: "江湖榜单 · 修复与复验",
  10: "江湖榜单 · 本地交付",
  11: "江湖榜单 · 运行实录",
  12: "江湖榜单 · 运行实录",
  13: "攻略站 · 运行成果",
  14: "配装器 · 运行成果",
  23: "论剑 · 接口接入案例",
  21: "成就百科 · 公共业务能力库测试",
  33: "论剑 · 页面重设计",
  37: "下一阶段 · 界面迁移",
  38: "下一阶段 · 公共业务能力库测试",
  39: "下一阶段 · 全链路自动化测试",
};
let activeIndex = -1;
let activeAsset = -1;
let subtitlesOn = true;
let scrubbing = false;
let playbackFrame = 0;
let zoomWasPlaying = false;

function element(tag, className, value) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (value !== undefined) node.textContent = value;
  return node;
}

function makeButton(label, action, className) {
  const button = element("button", className, label);
  button.type = "button";
  button.addEventListener("click", action);
  return button;
}

function makeImage(path, alt) {
  const image = element("img");
  image.src = path;
  image.alt = alt;
  image.addEventListener("click", () => {
    zoomWasPlaying = !audio.paused;
    audio.pause();
    zoom.querySelector("img").src = path;
    zoom.showModal();
  });
  return image;
}

function timeLabel(time) {
  const whole = Math.floor(Math.max(0, time));
  const m = String(Math.floor(whole / 60)).padStart(2, "0");
  const s = String(whole % 60).padStart(2, "0");
  return m + ":" + s;
}

function list(items) {
  const result = element("div", "list");
  for (const [title, detail] of items) {
    const row = element("div");
    row.append(element("strong", "", title), element("span", "", detail));
    result.append(row);
  }
  return result;
}

function route(items) {
  const result = element("div", "route");
  result.style.setProperty("--steps", items.length);
  for (const [title, detail] of items) {
    const step = element("article");
    step.append(element("h2", "", title));
    if (detail) step.append(element("p", "", detail));
    result.append(step);
  }
  return result;
}

function integration(items) {
  const result = element("div", "integration");
  const inputs = list(items);
  const connector = element("div", "connector");
  connector.setAttribute("aria-hidden", "true");
  connector.append(element("i"), element("i"), element("i"));
  const output = element("div", "integration-output");
  output.append(element("h2", "", "小程序交付"),
    element("p", "", "可操作功能、验证结果与待接续事项"));
  result.append(inputs, connector, output);
  return result;
}

function imageRow(scene, labels) {
  const result = element("div", "images");
  scene.images.forEach((path, index) => {
    const figure = element("figure");
    figure.append(makeImage(path, labels[index] || scene.title));
    if (labels[index]) figure.append(element("figcaption", "", labels[index]));
    result.append(figure);
  });
  return result;
}

function evidence(scene) {
  const root = element("div", "evidence");
  const proof = element("div", "proof");
  const more = element("div", "more");
  more.setAttribute("aria-label", "同一幕中的画面");
  const assets = scene.clips || scene.images;
  if (assets.length > 1) {
    assets.forEach((_, index) => {
      const button = makeButton(String(index + 1), () => {
        jump(scene.start + index * scene.duration / assets.length + .01);
      });
      button.setAttribute("aria-label", "查看画面 " + (index + 1));
      more.append(button);
    });
  }
  root.append(proof, more);
  return root;
}

function metrics(scene) {
  const grid = element("div", "metric");
  const keys = element("div", "metric-row keys");
  const pair = scene.metric_labels || ["原先手工完成", "采用 AI 工作流后"];
  for (const label of ["场景", pair[0], "", pair[1]]) keys.append(element("span", "", label));
  grid.append(keys);
  for (const [label, from, to, note] of scene.items) {
    const row = element("div", "metric-row");
    const result = element("div", "metric-result");
    result.append(element("strong", "", to));
    if (note) result.append(element("small", "metric-note", note));
    row.append(element("h2", "", label), element("strong", "", from), element("span", "", "→"), result);
    grid.append(row);
  }
  return grid;
}

function firstScene() {
  const slide = element("article", "slide hero");
  const heading = element("header");
  const title = element("h1");
  title.append(element("span", "", "推栏前端"), element("span", "", "工作流"));
  heading.append(element("p", "kicker", "阶段成果汇报 · 2026.11"),
    title, element("p", "lead", "从 App 业务迁移到小程序"),
    makeButton(audio.paused ? "▶ 开始播放" : "Ⅱ 暂停", toggle, "primary hero-play"));
  const art = element("div", "art");
  art.setAttribute("role", "img");
  art.setAttribute("aria-label", "三层玻璃透镜汇入 AI 光环");
  slide.append(heading, art);
  return slide;
}

function graphDemo(scene) {
  const figure = element("figure", "graph-demo");
  const label = element("figcaption", "graph-demo-label", "功能图谱 · 操作演示");
  const video = element("video");
  video.src = scene.demo;
  video.preload = "auto";
  video.muted = true;
  video.loop = true;
  video.playsInline = true;
  video.setAttribute("aria-label", "功能图谱演示视频");
  video.addEventListener("loadedmetadata", () => {
    if (video.isConnected) syncDemo(scenes[activeIndex], currentTime());
  });
  figure.append(label, video);
  return figure;
}

function buildScene(scene) {
  if (scene.index === 1) return firstScene();
  const slide = element("article", "slide");
  const heading = element("header");
  heading.append(element("p", "kicker", names[scene.sourceIndex] || chapters[scene.chapter - 1]),
    element("h1", "", scene.title));
  if (scene.lead) heading.append(element("p", "scene-lead", scene.lead));
  let content;
  const split = ["native", "phone", "side"].includes(scene.kind);
  if (split) {
    slide.classList.add("split", scene.kind === "phone" ? "portrait" : "wide-proof");
    if (scene.kind === "native") {
      heading.append(element("p", "", "Codex 对话实录"));
    } else if (scene.sourceIndex === 23) {
      const feature = element("div", "hero-metric");
      const bars = element("div", "bars");
      bars.setAttribute("aria-hidden", "true");
      bars.append(element("i"), element("i"));
      feature.append(element("b", "", "2.5 → 1 天"), element("span", "", "12 个强相关接口 · 含人工审核与调整"), bars);
      heading.append(feature);
    } else {
      heading.append(list(scene.items));
    }
    content = evidence(scene);
  } else if (scene.kind === "gallery") {
    content = evidence(scene);
  } else if (scene.kind === "graph") {
    content = route(scene.items);
  } else if (scene.kind === "phones") {
    content = imageRow(scene, ["社区入口", "内容分类", "公告正文", "图文阅读"]);
  } else if (scene.kind === "equipment") {
    content = imageRow(scene, ["选装前 · 攻击力 2295", "选装后 · 攻击力 3000"]);
    content.classList.add("equipment");
    const result = element("aside", "hero-metric");
    result.append(element("b", "", "2295 → 3000"), element("span", "", "攻击力 · 总装分 0 → 2392"));
    content.insertBefore(result, content.lastElementChild);
  } else if (scene.kind === "metrics") {
    content = metrics(scene);
  } else if (scene.kind === "ui_flow") {
    content = element("div", "steps-content");
    content.append(route([["AI 创建"], ["AI 审核与修正"], ["人工审核"], ["前端承接"]]), list(scene.items));
  } else if (scene.kind === "integration") {
    content = integration(scene.items);
  } else if (scene.kind === "module_list") {
    content = route(scene.items);
  } else {
    content = element("div", "statement");
    content.append(list(scene.items));
  }
  content.classList.add("content");
  if (scene.demo) {
    const layout = element("div", "content demo-layout");
    layout.append(content, graphDemo(scene));
    content = layout;
  }
  slide.append(heading, content);
  if (scene.foot) slide.append(element("p", "foot", scene.foot));
  return slide;
}

function showAsset(scene, time) {
  const proof = stage.querySelector(".proof");
  if (!proof) return;
  const assets = scene.clips || scene.images;
  const elapsed = Math.max(0, time - scene.start);
  const interval = scene.duration / assets.length;
  const index = Math.min(assets.length - 1, Math.floor(elapsed / interval));
  if (activeAsset !== index) {
    const path = assets[index];
    if (scene.clips) {
      const video = element("video");
      video.src = path;
      video.muted = true;
      video.playsInline = true;
      video.preload = "auto";
      video.setAttribute("aria-label", scene.title + "实录");
      video.addEventListener("loadedmetadata", () => {
        if (video.isConnected) syncClip(scene, currentTime(), index);
      });
      proof.replaceChildren(video);
    } else {
      proof.replaceChildren(makeImage(path, scene.title + " · 原始截图"));
    }
    proof.parentNode.querySelectorAll(".more button").forEach((button, i) => button.setAttribute("aria-current", String(i === index)));
    activeAsset = index;
  }
  if (scene.clips) syncClip(scene, time, index);
}

function syncClip(scene, time, index) {
  const video = stage.querySelector(".proof video");
  if (!video || video.readyState < 1) return;
  const seekTime = Math.max(0, time - scene.start - index * scene.duration / scene.clips.length);
  const target = Math.min(seekTime, video.duration - .04);
  if (Math.abs(video.currentTime - target) > .32) video.currentTime = target;
  if (audio.paused || video.ended) {
    if (!video.paused) video.pause();
  } else if (video.paused) {
    video.play().catch(() => {});
  }
}

function syncDemo(scene, time) {
  const video = stage.querySelector(".graph-demo video");
  if (!video || video.readyState < 1 || !Number.isFinite(video.duration) || video.seeking) return;
  const target = Math.max(0, time - scene.start) % video.duration;
  if (Math.abs(video.currentTime - target) > .35) video.currentTime = target;
  if (audio.paused) {
    if (!video.paused) video.pause();
  } else if (video.paused) {
    video.play().catch(() => {});
  }
}

function currentTime() {
  return Math.min(seconds, Math.max(0, audio.currentTime));
}

function paint(time) {
  const index = Math.max(0, scenes.findLastIndex((scene) => scene.start <= time + .0005));
  const scene = scenes[index];
  const chapter = scene.chapter - 1;
  if (index !== activeIndex) {
    activeIndex = index;
    activeAsset = -1;
    presentation.dataset.chapter = scene.chapter;
    stage.replaceChildren(buildScene(scene));
    $("current-section").textContent = chapters[chapter] + " · " + scene.index + " / " + scenes.length;
    chapterButtons.forEach((button, i) => {
      button.setAttribute("aria-current", String(i === chapter));
      button.toggleAttribute("data-passed", i < chapter);
    });
    $("previous").disabled = index === 0;
    $("next").disabled = index === scenes.length - 1;
  }
  showAsset(scene, time);
  if (scene.demo) syncDemo(scene, time);
  const heroButton = stage.querySelector(".hero-play");
  if (heroButton) heroButton.textContent = audio.paused ? "▶ 开始播放" : "Ⅱ 暂停";
  if (!scrubbing) progress.value = time;
  progress.style.setProperty("--played", (time / seconds * 100).toFixed(3) + "%");
  const chapterDuration = (chapterStarts[chapter + 1] ?? seconds) - chapterStarts[chapter];
  const modulePlayed = Math.min(1, Math.max(0, (time - chapterStarts[chapter]) / chapterDuration));
  chapterButtons[chapter].style.setProperty("--chapter-played", (modulePlayed * 100).toFixed(2) + "%");
  progress.setAttribute("aria-valuetext", timeLabel(time));
  $("clock").textContent = timeLabel(time) + " / " + timeLabel(seconds);
  const cue = subtitlesOn && captions.findLast((line) => line.start <= time && line.end > time);
  caption.hidden = !cue || audio.ended;
  if (cue) {
    const text = cue.text.replaceAll("\n", "");
    if (caption.textContent !== text) caption.textContent = text;
  }
}

function animate() {
  paint(currentTime());
  if (!audio.paused && !audio.ended) playbackFrame = requestAnimationFrame(animate);
}

function jump(time) {
  const bound = Math.min(Math.max(0, time), seconds);
  audio.currentTime = bound;
  paint(bound);
}

function seekScene(index) {
  jump(scenes[Math.max(0, Math.min(scenes.length - 1, index))].start + .005);
}

function toggle() {
  if (!audio.paused) {
    audio.pause();
    return;
  }
  if (audio.ended || currentTime() >= seconds - .05) jump(0);
  audio.play().catch(() => {
    status.textContent = "播放失败，请确认 media 与 HTML 在同一目录，再点击播放。";
    status.hidden = false;
  });
}

function fullScreen() {
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  else $("presentation").requestFullscreen().catch(() => {});
}

const chapterIndices = chapters.map((_, index) => scenes.findIndex((scene) => scene.chapter === index + 1));
const chapterStarts = chapterIndices.map((index) => scenes[index].start);
const chapterButtons = chapters.map((name, index) => makeButton(name, () => seekScene(chapterIndices[index])));
$("chapters").append(...chapterButtons);
$("home").onclick = () => jump(0);
$("previous").onclick = () => seekScene(activeIndex - 1);
$("next").onclick = () => seekScene(activeIndex + 1);
$("full").onclick = fullScreen;
playButton.onclick = toggle;
$("mute").onclick = () => {
  audio.muted = !audio.muted;
  $("mute").textContent = audio.muted ? "取消静音" : "静音";
  $("mute").setAttribute("aria-pressed", String(audio.muted));
};
$("cc").onclick = () => {
  subtitlesOn = !subtitlesOn;
  $("cc").setAttribute("aria-pressed", String(subtitlesOn));
  paint(currentTime());
};
progress.max = seconds;
progress.addEventListener("pointerdown", () => { scrubbing = true; });
for (const event of ["pointerup", "pointercancel", "change"]) progress.addEventListener(event, () => { scrubbing = false; });
progress.addEventListener("input", () => jump(Number(progress.value)));
audio.addEventListener("play", () => {
  status.hidden = true;
  playButton.textContent = "Ⅱ 暂停";
  cancelAnimationFrame(playbackFrame);
  animate();
});
audio.addEventListener("pause", () => {
  playButton.textContent = audio.ended ? "↻ 重播" : "▶ 播放";
  cancelAnimationFrame(playbackFrame);
  paint(currentTime());
});
audio.addEventListener("ended", () => {
  playButton.textContent = "↻ 重播";
  paint(seconds);
});
audio.addEventListener("seeked", () => paint(currentTime()));
zoom.querySelector("button").onclick = () => zoom.close();
zoom.addEventListener("close", () => { if (zoomWasPlaying) audio.play().catch(() => {}); });
document.addEventListener("keydown", (event) => {
  if (zoom.open || event.altKey || event.ctrlKey || event.metaKey || ["INPUT", "BUTTON"].includes(event.target.tagName)) return;
  if (event.key === " ") { event.preventDefault(); toggle(); }
  if (event.key === "ArrowRight") { event.preventDefault(); seekScene(activeIndex + 1); }
  if (event.key === "ArrowLeft") { event.preventDefault(); seekScene(activeIndex - 1); }
  if (event.key.toLowerCase() === "f") fullScreen();
});
if (narrationFile && location.origin === "http://10.11.177.26:8788") {
  // The original share server only serves the legacy audio path.
  audio.addEventListener("error", () => {
    const updatedShare = new URL(location.href);
    updatedShare.port = "8789";
    location.replace(updatedShare);
  }, { once: true });
}
audio.src = narrationFile || ("media/narration.mp3?v=" + encodeURIComponent(narrationVersion));
const requestedScene = Number(new URLSearchParams(location.search).get("scene"));
if (Number.isInteger(requestedScene) && requestedScene >= 1 && requestedScene <= scenes.length) {
  seekScene(requestedScene - 1);
} else {
  paint(0);
}
